Christmas Pack (combined) - Minecraft 26.3
Merges the Christmas texture pack (by Futureazoo; see credits.txt) with:
- Christmas Mobs: Santa hats with a drooping tail and pom-pom, scarves, string lights, reindeer horses (textures only, no extra mods)
- Christmas Tools: candy cane handles on every tool (including held spears), green netherite tools
- Candy cane hunger icons, and a candy cane border, holly and scattered Christmas light bulbs on inventory and container screens
- Candy cane elytra wings (moved to the 26.3 texture path so they show on the player)
Where the base pack already had its own mob texture (bee, enderman, iron golem, shulkers, slime, witch),
the Santa hat / lights were added on top of that texture instead of replacing it.
Grass blocks, short and tall grass and bushes use vanilla green.
