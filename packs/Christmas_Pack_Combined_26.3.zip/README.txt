Christmas Pack (combined) - Minecraft 26.3
Merges the Christmas texture pack (by Futureazoo; see credits.txt) with:
- Christmas Mobs: Santa hats, scarves, string lights, reindeer horses (textures only, no extra mods)
- Christmas Tools: candy cane handles on every tool, green netherite tools
Where the base pack already had its own mob texture (bee, enderman, iron golem, shulkers, slime),
the Santa hat / lights were added on top of that texture instead of replacing it.
Grass blocks, short and tall grass and bushes use vanilla green.
